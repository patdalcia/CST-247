﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace CST_247_Topic_3_Activity2.Models
{
    public class ButtonModel
    {
        public bool State { get; set; }

        public ButtonModel(bool state)
        {

        }
    }
}